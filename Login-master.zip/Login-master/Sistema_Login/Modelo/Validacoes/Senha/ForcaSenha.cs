﻿namespace VerificaForcaSenha.Modelo.Senha
{
    public enum ForcaDaSenha
    {
        Inaceitavel,
        Fraca,
        Aceitavel,
        Forte,
        Segura
    }

}
